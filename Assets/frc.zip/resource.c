/*
  resource.c - Resource handling.

  Jason Hood, 6 June, 2010.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>


WORD langid = 1033;
int  update = INT_MAX;

typedef struct
{
  BOOL	 html;
  LPWSTR text;
  int	 len;
  int	 line;
} Resource;

// Since there can "only" be 65536 (since I'm enforcing different string & HTML
// identifiers), save a bit of effort and just use an array.
static Resource res[65536];
static int count;


// Add a resource, either HTML (if HTML is TRUE) or string.  Returns 0 if added,
// 1 if already exists as string, 2 if already exists as HTML.	On entry, LINE
// contains the line number where ID is defined; on exit, it is set to the
// previous definition (unchanged if none).
int AddResource( BOOL html, int id, LPWSTR text, int len, int* line )
{
  id &= 0xFFFF;

  if (res[id].len != 0)
  {
    *line = res[id].line;
    return (res[id].html) ? 2 : 1;
  }

  res[id].html = html;
  res[id].text = malloc( len * 2 );
  memcpy( res[id].text, text, len * 2 );
  res[id].len  = len;
  res[id].line = *line;

  ++count;

  return 0;
}


// Write the resources to file NAME.
BOOL WriteResources( LPCSTR name )
{
  HANDLE handle;
  LPWSTR buf, p;
  int	 len, max, writ;
  int	 i, s;
  int	 cnt;
  FILE*  con;

  handle = BeginUpdateResource( name, FALSE );
  if (handle == NULL)
    return FALSE;

  buf = NULL;
  max = writ = 0;

  cnt = 0;
  con = fopen( "con", "w" );
  setvbuf( con, NULL, _IONBF, 0 );

  // Update each block of 16 strings.
  for (i = 0; i < 65536; i += 16)
  {
    len = 0;
    for (s = 0; s < 16; ++s)
    {
      if (!res[i+s].html)
	len += res[i+s].len * 2;
    }
    if (len != 0)
    {
      len += 16 * 2;
      if (len > max)
      {
	max = len;
	buf = realloc( buf, max );
      }
      p = buf;
      for (s = 0; s < 16; ++s)
      {
	if (!res[i+s].html && res[i+s].len != 0)
	{
	  *p++ = res[i+s].len;
	  memcpy( p, res[i+s].text, res[i+s].len * 2 );
	  p += res[i+s].len;
	  ++cnt;
	}
	else
	{
	  *p++ = 0;
	}
      }
      if (writ + len >= update)
      {
	fprintf( con, "%d%%\r", cnt * 100 / count );
	if (!EndUpdateResource( handle, FALSE ))
	{
	  fprintf( stderr, "EndUpdateResource failed at string %d (%d bytes).\n", i, writ );
	  return FALSE;
	}
	handle = BeginUpdateResource( name, FALSE );
	writ = 0;
      }
      UpdateResource( handle, RT_STRING, MAKEINTRESOURCE( (i >> 4) + 1 ),
		      langid, buf, len );
      writ += len;
    }
  }

  if (buf != NULL)
    free( buf );

  // Update each HTML resource.
  for (i = 0; i < 65536; ++i)
  {
    if (res[i].html)
    {
      if (writ + len >= update)
      {
	fprintf( con, "%d%%\r", cnt * 100 / count );
	if (!EndUpdateResource( handle, FALSE ))
	{
	  fprintf( stderr, "EndUpdateResource failed at HTML %d (%d bytes).\n", i, writ );
	  return FALSE;
	}
	handle = BeginUpdateResource( name, FALSE );
	writ = 0;
      }
      UpdateResource( handle, RT_HTML, MAKEINTRESOURCE( i ), langid,
		      res[i].text, res[i].len * 2 );
      writ += res[i].len * 2;
      ++cnt;
    }
  }

  fputs( "    \r", con );
  fclose( con );

  // Free the memory.
  for (i = 0; i < 65536; ++i)
    if (res[i].text != NULL)
      free( res[i].text );

  return EndUpdateResource( handle, FALSE );
}
