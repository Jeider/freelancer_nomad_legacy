/*
  res2frc.c - Extract string & HTML resources.

  Jason Hood, 26 June to 7 July, 2010.

  v1.10, 1 to 8 May, 2012.
  v1.11, 3 February, 2024.

  Given a set of files, the string and HTML resources are extracted and saved
  in the .frc format.  NO OTHER resources are extracted.  I was lazy, so an
  explicit backslash will continue lines (i.e. there is no option to just leave
  trailing space) and uppercase characters will terminate sequences (i.e. it
  doesn't use braces).
*/

#define PVERS "1.11"
#define PDATE "3 February, 2024"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <conio.h>
#include <stdarg.h>

#ifndef WC_NO_BEST_FIT_CHARS
#define WC_NO_BEST_FIT_CHARS 0x400
#endif

#define SIZEOF(a) (sizeof(a) / sizeof(*a))

//#include <stdbool.h>
#define bool  BOOL
#define true  TRUE
#define false FALSE


// Test if the strings S1 & S2 are equal.
#define STREQ(	s1, s2 ) (strcmp(  s1, s2 ) == 0)
#define STRIEQ( s1, s2 ) (stricmp( s1, s2 ) == 0)
#define WCSEQ(	s1, s2 ) (wcscmp(  s1, s2 ) == 0)

// Test if the string S1 starts with the static string S2.
#define WCSBEG( s1, s2 ) (wcsncmp( s1, s2, SIZEOF(s2) - 1 ) == 0)


bool   unicode;
int    width = -1, margin;
int    col;
bool   HTML;
FILE*  out;
bool   blank_line;
int    resid;
LPWSTR buffer;
int    buflen, bufmax;
int    lang;

#define ELEMATTR 8
LPWSTR elemdata[1+ELEMATTR*2];
int    elemattr;


LPCSTR standard_dlls[] =
{
  "Resources.dll",
  "InfoCards.dll",
  "MiscText.dll",
  "NameResources.dll",
  "EquipResources.dll",
  "OfferBribeResources.dll",
  "MiscTextInfo2.dll"
};

#define STANDARD_DLLS 7


enum { TRA_bold      = 0x01,
       TRA_italic    = 0x02,
       TRA_underline = 0x04,
       TRA_font      = 0xF8,
       TRA_color     = 0xFFFFFF00
     };

enum { JUST_left,
       JUST_center,
       JUST_right
     };


struct sRGB
{
  int  rgb;
  char alias[4];
}
SimpleRGB[] =
{
  { 0x000000, "z"  },   // black (zero)
  { 0x000004, "dr" },   // dark red
  { 0x000008, "hr" },   // half red
  { 0x00000C, "lr" },   // light red
  { 0x0000FF, "r"  },   // red
  { 0x000400, "dg" },   // dark green
  { 0x000404, "dy" },   // dark yellow
  { 0x000800, "hg" },   // half green
  { 0x000808, "hy" },   // half yellow
  { 0x000C00, "lg" },   // light green
  { 0x000C0C, "ly" },   // light yellow
  { 0x00FF00, "g"  },   // green
  { 0x00FFFF, "y"  },   // yellow
  { 0x040000, "db" },   // dark blue
  { 0x040004, "dm" },   // dark magenta
  { 0x040400, "dc" },   // dark cyan
  { 0x040404, "dw" },   // dark white
  { 0x080000, "hb" },   // half blue
  { 0x080008, "hm" },   // half magenta
  { 0x080800, "hc" },   // half cyan
  { 0x080808, "hw" },   // half white
  { 0x0C0000, "lb" },   // light blue
  { 0x0C000C, "lm" },   // light magenta
  { 0x0C0C00, "lc" },   // light cyan
  { 0x0C0C0C, "lw" },   // light white
  { 0xFF0000, "b"  },   // blue
  { 0xFF00FF, "m"  },   // magenta
  { 0xFFFF00, "c"  },   // cyan
  { 0xFFFFFF, "w"  },   // white
};

int sRGBcmp( const void* key, const void* elem )
{
  return ((int)key - ((struct sRGB*)elem)->rgb);
}

struct nRGB {
  int rgb;
  LPCSTR name;
}
NamedRGB[] =
{
  { 0x080808, "Gray" },         // not used, hw takes precedence
  { 0x0E3C78, "Aqua" },
  { 0x0E8484, "Blue" },
  { 0x25AE5F, "Yellow" },
  { 0x2C0088, "Fuchsia" },
  { 0xD1D1FB, "Red" },
  { 0xD1FBB3, "Green" },
  { 0xFFFFFF, "White" },        // not used, w takes precedence
};

int nRGBcmp( const void* key, const void* elem )
{
  return ((int)key - ((struct nRGB*)elem)->rgb);
}


LPCWSTR GetString( HMODULE, UINT, int* );
LPCWSTR GetHTML(   HMODULE, UINT, int* );
BOOL CALLBACK GetLanguage( HANDLE hModule, LPCTSTR lpszType, LPCTSTR lpszName,
			   WORD wIDLanguage, long lParam );

void outputS( LPCWSTR );
void outputf( LPCSTR, ... );
void outputs( LPCSTR );
void outputc( int );
void outputn( bool );
void indent( void );

void format( LPCWSTR, int );

LPCSTR split( LPCSTR, LPCSTR* );


int main( int argc, char* argv[] )
{
  LPCWSTR txt;
  int	  len;
  HMODULE handle;
  char	  outn[MAX_PATH], outpath[MAX_PATH];
  LPCSTR  name, dot;
  int	  id, lastid, rid;
  bool	  str, html;
  BYTE*   seen_str;
  bool	  seen_first;

  if (argc == 1 ||
      ((argv[1][0] == '/' || argv[1][0] == '-') && argv[1][1] == '?') ||
      STREQ( argv[1], "--help" ))
  {
    bool gui = false;
    if (argc == 1)
    {
      // Simple test to see if we were run from a GUI window.
      CONSOLE_SCREEN_BUFFER_INFO csbi;
      if (GetConsoleScreenBufferInfo( GetStdHandle( STD_OUTPUT_HANDLE ), &csbi )
	  && csbi.dwCursorPosition.X == 0 && csbi.dwCursorPosition.Y == 0)
      {
	gui = true;
      }
    }
    puts( "Res2FRC by Jason Hood <jadoxa@yahoo.com.au>.\n"
	  "Version " PVERS " (" PDATE ").  Freeware.\n"
	  "http://freelancer.adoxa.vze.com/\n"
	  "\n"
	  "Extract the text from Freelancer resource DLLs.\n"
	  "\n"
	  "res2frc [-i indent] [-o path] [-r pos] [-u] [-w width] infile [-o outfile] ...\n"
	  "\n"
	  "-i\tset indentation to INDENT spaces (default is one tab)\n"
	  "  \tuse a negative INDENT to set the tab size (default is 8)\n"
	  "-o\tthe directory to write the output files\n"
	  "-r\tINFILE's position in freelancer.ini's [Resources] section\n"
	  "  \tautomatically set for the standard files\n"
	  "  \tif specified, it will be increased for each INFILE\n"
	  "-u\tcreate a Unicode file, not ANSI\n"
	  "-w\tset maximum columns to WIDTH (use 0 to prevent wrap)\n"
	  "infile\tread resources from INFILE[.dll], generating [PATH\\]INFILE.frc,\n"
	  "      \tor OUTFILE[.frc]\n"
	  "\n"
	  "ONLY the string and HTML resources are extracted.\n"
	  "\n"
	  "Example:\n"
	  "\tres2frc -o frc file1.ext file2.ext -o file3 file4 -o file5.ext\n"
	  "\n"
	  "\tfile1.ext -> frc\\file1.frc\n"
	  "\tfile2.ext -> file3.frc\n"
	  "\tfile4.dll -> file5.ext"
	);
    if (gui)
    {
      puts( "\nPress any key to exit (try running from Command Prompt)." );
      while (_kbhit()) _getch();
      _getch();
    }
    return 0;
  }
  if (STREQ( argv[1], "--version" ))
  {
    puts( "Res2FRC version " PVERS " (" PDATE ")." );
    return 0;
  }

  *outpath = '\0';
  while (*++argv != NULL && **argv == '-')
  {
    while (*++*argv != '\0')
    {
      int* n;
      switch (**argv)
      {
	case 'o':
	  if (argv[0][1] != '\0')
	    strncpy( outpath, argv[0] + 1, MAX_PATH-2 );
	  else if (argv[1] != NULL)
	    strncpy( outpath, *++argv, MAX_PATH-2 );
	  outpath[MAX_PATH-2] = '\0';
	goto break2;

	case 'u': unicode = true; break;

	case 'i': n = &margin; goto do_num;
	case 'r': n = &resid;  goto do_num;
	case 'w': n = &width;
	do_num:
	{
	  char	o = **argv;
	  char* num;
	  bool	cntnu = false;
	  if (argv[0][1] != '\0')
	    num = *argv + 1, cntnu = true;
	  else
	    num = *++argv;
	  if (num != NULL)
	  {
	    char* end;
	    *n = strtol( num, &end, 10 );
	    if (end != num && (cntnu || *end == '\0'))
	      *argv = end - 1;
	    else
	      num = NULL;
	  }
	  if (num == NULL)
	  {
	    fprintf( stderr, "Expecting number for -%c.\n", o );
	    return 1;
	  }
	}
	break;

	default:
	  fprintf( stderr, "Unknown option '%c'.\n", **argv );
	  return 1;
      }
    }
    break2: ;
  }

  if (*outpath != '\0')
  {
    bool  end;
    LPSTR path = outpath;
    do
    {
      while (*path != '\\' && *path != '/' && *path != '\0')
	++path;
      end = (*path == '\0');
      *path = '\0';
      if (!CreateDirectory( outpath, NULL ) &&
	  GetLastError() != ERROR_ALREADY_EXISTS)
      {
	fprintf( stderr, "Unable to create \"%s\".\n", outpath );
	return 1;
      }
      *path++ = '\\';
    } while (!end && *path != '\0');
    *path = '\0';
  }

  if (margin == 0)
    margin = -8;

  if (resid < 0)
    resid = 0;

  if (width < 0)
  {
    HANDLE con;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    con = CreateFile( "CONOUT$", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_WRITE,
		      NULL, OPEN_EXISTING, 0, NULL );
    width = (GetConsoleScreenBufferInfo( con, &csbi )) ? csbi.dwSize.X : 80;
    CloseHandle( con );
  }
  else if (width == 0)
    width = INT_MAX;

  // Prevent message box on bad files.
  SetErrorMode( SEM_FAILCRITICALERRORS );

  seen_str = malloc( 65536 );

  for (; *argv != NULL; ++argv)
  {
    handle = LoadLibraryEx( *argv, NULL, LOAD_LIBRARY_AS_DATAFILE );
    if (handle == NULL)
    {
      fprintf( stderr, "Unable to load \"%s\".\n", *argv );
      continue;
    }

    name = split( *argv, &dot );
    for (id = 0; id < STANDARD_DLLS; ++id)
    {
      if (STRIEQ( name, standard_dlls[id] ))
      {
	rid = id;
	break;
      }
    }
    if (id == STANDARD_DLLS)
    {
      rid = resid;
      if (resid != 0)
	++resid;
    }

    if (argv[1] != NULL && argv[1][0] == '-' && argv[1][1] == 'o' )
    {
      if (argv[1][2] == '\0')
      {
	if (argv[2] == NULL)
	  goto inout;
	argv += 2;
      }
      else
      {
	++argv;
	*argv += 2;
      }
      split( *argv, &dot );
      _snprintf( outn, MAX_PATH, (*dot == '\0') ? "%s.frc" : "%s", *argv );
    }
    else
    {
    inout:
      if (*outpath == '\0')
	name = *argv;
      _snprintf( outn, MAX_PATH, "%s%.*s.frc", outpath, dot - name, name );
    }

    out = fopen( outn, "wb" );
    if (out == NULL)
    {
      fprintf( stderr, "Unable to create \"%s\".\n", outn );
      FreeLibrary( handle );
      continue;
    }

    memset( seen_str, false, 65536 );
    seen_first = false;
    str = html = false;
    lastid = 0;
    lang = -1;
    HTML = false;
    for (id = 0; id < 65536; ++id)
    {
      if ((txt = GetString( handle, id, &len )))
      {
	seen_str[id] = true;
	if (!str)
	{
	  str = true;
	  if (unicode)
	    putwc( L'\xFEFF', out );
	  if (lang == -1)
	  {
	    EnumResourceLanguages( handle, RT_STRING,
				   MAKEINTRESOURCE( (id >> 4) + 1 ),
				   GetLanguage, 0 );
	  }
	}
	else if (blank_line || (lastid + 1 != id && lastid + 5 != id))
	{
	  outputn( false );
	}
	lastid = id;

	outputf( "S %d", (rid << 16) + id );
	if (margin <= -9)
	{
	  outputc( '\t' );
	  col = -margin;
	}
	else
	{
	  outputf( "%*c", ((margin < 9) ? 9 : margin) - col, ' ' );
	}

	format( txt, len );

	outputn( false );
      }
    }

    HTML = true;
    for (id = 0; id < 65536; ++id)
    {
      if ((txt = GetHTML( handle, id, &len )))
      {
	if (seen_str[id])
	{
	  if (!seen_first)
	  {
	    seen_first = true;
	    fputs( "Duplicated ids:", stderr );
	  }
	  else
	    putc( ',', stderr );
	  fprintf( stderr, " %d", id );
	}
	if (!html)
	{
	  html = true;
	  if (!str)
	  {
	    if (unicode)
	      putwc( L'\xFEFF', out );
	    if (lang == -1)
	    {
	      EnumResourceLanguages( handle, RT_HTML, MAKEINTRESOURCE( id ),
				     GetLanguage, 0 );
	    }
	  }
	  else
	  {
	    outputn( false );
	    outputn( false );
	  }
	}
	else
	{
	  outputn( false );
	}

	outputf( "H %d", (rid << 16) + id );

	format( txt, len );

	outputn( false );
      }
    }

    FreeLibrary( handle );
  }

  free( seen_str );
  if (buffer != NULL)
    free( buffer );

  return 0;
}


// Given a path, return a pointer to the name, setting EXT to the extension.
LPCSTR split( LPCSTR path, LPCSTR* ext )
{
  LPCSTR name;

  if (ext != NULL)
    *ext = NULL;

  for (name = path; *path != '\0'; ++path)
  {
    if (*path == '/' || *path == '\\')
      name = path + 1;
    else if (ext != NULL && *path == '.')
      *ext = path;
  }
  if (ext != NULL)
    if (*ext == NULL || *ext <= name)
      *ext = path;

  return name;
}


// Read an element, copying it and its attributes to the global buffer,
// returning its entire length (i.e. including the '>').  TAG is assumed to
// point at the opening '<'.
int get_element( LPCWSTR tag )
{
  LPCWSTR begin;
  LPWSTR  buf;
  WCHAR   quote;

  if (iswspace( *++tag ))
    return 0;

  elemattr = 0;
  elemdata[0] = buf = buffer;
  begin = tag;
  if (*tag == '/')
    *buf++ = *tag++;
  while (!iswspace( *tag ) && !(tag[0] == '/' && tag[1] == '>') && *tag != '>')
    *buf++ = *tag++;
  *buf++ = '\0';

  do
  {
    while (iswspace( *tag ))
      ++tag;
    if (elemattr < ELEMATTR)
      elemdata[elemattr*2+1] = buf;
    else if (!(*tag == '>' || (tag[0] == '/' && tag[1] == '>')))
      return 0;
    while (!iswspace( *tag ) && *tag != '=' && *tag != '>')
      *buf++ = *tag++;
    *buf++ = '\0';

    while (iswspace( *tag ))
      ++tag;
    if (*tag == '=')
    {
      ++tag;
      while (iswspace( *tag ))
	++tag;
      quote = *tag++;
      if (quote != '\'' && quote != '"')
	return 0;
      if (elemattr < ELEMATTR)
	elemdata[++elemattr*2] = buf;
      while (*tag != quote)
	*buf++ = *tag++;
      ++tag;
    }
    *buf++ = '\0';
  } while (*tag != '>');

  return tag - begin + 2;
}


// Convert an attribute value to an integer.
int avtoi( LPCWSTR v )
{
  if (v[0] == '0' && v[1] == 'x')       // yes, it is case sensitive
    return wcstoul( v, NULL, 16 );
  return wcstol( v, NULL, 10 );
}


BYTE swap_nybbles( BYTE b )
{
  return (b >> 4) | (b << 4);
}


void format( LPCWSTR txt, int len )
{
  LPCWSTR begin;
  bool	  rdl;
  bool	  space, para, indented;
  bool	  in_text, in_tag;
  int	  tra, just;

  space = para = false;
  if (*txt == L'\xFEFF')
  {
    ++txt;
    --len;
  }

  rdl = (WCSBEG( txt, L"<?xml" ) || WCSBEG( txt, L"<RDL" ));

  if (rdl ^ HTML)
  {
    if (HTML)
      outputc( ' ' );
    outputc( '~' );
    space = true;
  }

  if (rdl)
  {
    // Ignore the XML signature, RDL/PUSH and POP/RDL tags.
    begin = txt;
    if (txt[1] == '?')
      txt = wcschr( txt, '>' ) + 1;
    txt += 12;			// <RDL><PUSH/>
    len -= txt - begin;
    // The original HTML resources end with two newlines.
    while (txt[len-1] != '>')
      --len;
    len -= 12;			// <POP/></RDL>

    if (len == 0)
    {
      outputs( " \\." );
      return;
    }
  }

  if (len > bufmax)
  {
    bufmax = len + 4;
    // Worst-case scenario: each character becomes \xNNNN.
    buffer = realloc( buffer, bufmax * 6 * 2 );
  }

  if (HTML)
    outputn( false );
  else if (space)
    outputc( ' ' );

  blank_line =
  space      = false;
  indented   =
  para	     =
  in_text    = !rdl;
  in_tag     = false;
  tra	     = 0;
  just	     = JUST_left;
  begin      = txt;
  while (len > 0)
  {
    if (col == 0)
    {
      indent();
      indented = true;
    }
    buflen = 0;
    if (*txt == '\n')
    {
      if (in_text || in_tag)
      {
	if (len == 1 || txt == begin)
	  outputs( "\\n" );
	else
	{
	  if (space)
	    outputs( "\\n\\" );
	  outputn( false );
	}
      }
      space = false;
      ++txt;
      --len;
    }
    else if (rdl && *txt == '<')
    {
      int tag = get_element( txt );
      if (tag == 0)
	goto bad_tag;

      if (WCSEQ( elemdata[0], L"PARA" ))
      {
	if (len == tag * 2 && WCSBEG( txt + tag, L"<PARA/>" ))
	{
	  outputs( "\\n" );
	  para = true;
	  break;
	}
	if (len == tag)
	{
	  if (space)
	    outputs( "\\n" );
	  else
	    para = true;
	}
	else if (txt == begin)
	{
	  outputs( "\\n" );
	}
	else
	{
	  if (space)
	    outputs( "\\n\\" );
	  outputn( false );
	}
	space = false;
      }
      else if (WCSEQ( elemdata[0], L"JUST" ))
      {
	if (elemattr != 1 || !WCSEQ( elemdata[1], L"loc" ))
	  goto bad_tag;
	if (*elemdata[2] == 'c' || *elemdata[2] == 'C')
	{
	  if (just != JUST_center)
	  {
	    just = JUST_center;
	    outputs( "\\m" );
	  }
	}
	else if (*elemdata[2] == 'r' || *elemdata[2] == 'R')
	{
	  if (just != JUST_right)
	  {
	    just = JUST_right;
	    outputs( "\\r" );
	  }
	}
	else
	{
	  if (just != JUST_left)
	  {
	    just = JUST_left;
	    outputs( "\\l" );
	  }
	}
      }
      else if (WCSEQ( elemdata[0], L"POS" ))
      {
	int h;
	if (elemattr != 2)
	  goto bad_tag;
	if (WCSEQ( elemdata[1], L"h" ) && WCSEQ( elemdata[3], L"relH" )
				       && WCSEQ( elemdata[4], L"true" ))
	  h = avtoi( elemdata[2] );
	else if (WCSEQ( elemdata[3], L"h" ) && WCSEQ( elemdata[1], L"relH" )
					    && WCSEQ( elemdata[2], L"true" ))
	  h = avtoi( elemdata[4] );
	else
	  goto bad_tag;
	outputf( "\\h%.3d", h );
      }
      else if (WCSEQ( elemdata[0], L"TEXT" ))
      {
	in_text = true;
      }
      else if (WCSEQ( elemdata[0], L"/TEXT" ))
      {
	in_text = false;
      }
      else if (WCSEQ( elemdata[0], L"TRA" ))
      {
	LPWSTR color;
	int    data, mask, def;
	int    a;

	color = NULL;
	data = mask = def = 0;
	for (a = 1; elemattr != 0; a += 2, --elemattr)
	{
	  if (WCSEQ( elemdata[a], L"data" ))
	  {
	    data = avtoi( elemdata[a+1] );
	    if (mask & TRA_color)
	      color = NULL;
	  }
	  else if (WCSEQ( elemdata[a], L"mask" ))
	  {
	    mask = avtoi( elemdata[a+1] );
	  }
	  else if (WCSEQ( elemdata[a], L"def" ))
	  {
	    def = avtoi( elemdata[a+1] );
	  }
	  else
	  {
	    bool d, on;
	    d = on = false;
	    if (WCSEQ( elemdata[a+1], L"default" ))
	      d = true;
	    else if (WCSEQ( elemdata[a+1], L"true" ))
	      on = true;
	    if (WCSEQ( elemdata[a], L"bold" ))
	    {
	      mask |= TRA_bold;
	      if (d)
		def |= TRA_bold;
	      else if (on)
		data |= TRA_bold;
	      else
		data &= ~TRA_bold;
	    }
	    else if (WCSEQ( elemdata[a], L"italic" ))
	    {
	      mask |= TRA_italic;
	      if (d)
		def |= TRA_italic;
	      else if (on)
		data |= TRA_italic;
	      else
		data &= ~TRA_italic;
	    }
	    else if (WCSEQ( elemdata[a], L"underline" ))
	    {
	      mask |= TRA_underline;
	      if (d)
		def |= TRA_underline;
	      else if (on)
		data |= TRA_underline;
	      else
		data &= ~TRA_underline;
	    }
	    else if (WCSEQ( elemdata[a], L"font" ))
	    {
	      mask |= TRA_font;
	      if (d)
		def |= TRA_font;
	      else
	      {
		data &= ~TRA_font;
		data |= (avtoi( elemdata[a+1] ) - 1) << 3;
	      }
	    }
	    else if (WCSEQ( elemdata[a], L"color" ))
	    {
	      mask |= TRA_color;
	      if (d)
		def |= TRA_color;
	      else if (*elemdata[a+1] == '#')
	      {
		int r, g, b;
		swscanf( elemdata[a+1]+1, L"%2x%2x%2x", &r, &g, &b );
		data &= ~TRA_color;
		data |= (r << 8) | (g << 16) | (b << 24);
		color = NULL;
	      }
	      else if (iswdigit( *elemdata[a+1] ))
	      {
		data &= ~TRA_color;
		data |= avtoi( elemdata[a+1] ) - 1;
		color = NULL;
	      }
	      else
		color = elemdata[a+1];
	    }
	  }
	}
	if (mask & TRA_bold)
	{
	  if ((def & TRA_bold) || !(data & TRA_bold))
	  {
	    if (tra & TRA_bold)
	    {
	      tra &= ~TRA_bold;
	      outputs( "\\B" );
	    }
	  }
	  else
	  {
	    if (!(tra & TRA_bold))
	    {
	      tra |= TRA_bold;
	      outputs( "\\b" );
	    }
	  }
	}
	if (mask & TRA_italic)
	{
	  if ((def & TRA_italic) || !(data & TRA_italic))
	  {
	    if (tra & TRA_italic)
	    {
	      tra &= ~TRA_italic;
	      outputs( "\\I" );
	    }
	  }
	  else
	  {
	    if (!(tra & TRA_italic))
	    {
	      tra |= TRA_italic;
	      outputs( "\\i" );
	    }
	  }
	}
	if (mask & TRA_underline)
	{
	  if ((def & TRA_underline) || !(data & TRA_underline))
	  {
	    if (tra & TRA_underline)
	    {
	      tra &= ~TRA_underline;
	      outputs( "\\U" );
	    }
	  }
	  else
	  {
	    if (!(tra & TRA_underline))
	    {
	      tra |= TRA_underline;
	      outputs( "\\u" );
	    }
	  }
	}
	if (mask & TRA_font)
	{
	  if (def & TRA_font)
	  {
	    if (tra & TRA_font)
	    {
	      tra &= ~TRA_font;
	      outputs( "\\F" );
	    }
	  }
	  else
	  {
	    tra |= TRA_font;
	    outputf( "\\f%.2d", (data >> 3) + 1 );
	  }
	}
	if (mask & TRA_color)
	{
	  if (def & TRA_color)
	  {
	    if (tra & TRA_color)
	    {
	      tra &= ~TRA_color;
	      outputs( "\\C" );
	    }
	  }
	  else
	  {
	    tra |= TRA_color;
	    if (color != NULL)
	    {
	      // Take advantage of buffer organization to simplify.
	      color[-2] = '\\';
	      color[-1] = 'c';
	      color[0] &= ~0x20;	// start with capital
	      outputS( color-2 );
	    }
	    else
	    {
	      struct sRGB* sim;
	      sim = bsearch( (void*)((UINT)data >> 8), SimpleRGB,
			     SIZEOF(SimpleRGB), sizeof(*SimpleRGB), sRGBcmp );
	      if (sim != NULL)
	      {
		outputf( "\\c%s", sim->alias );
	      }
	      else
	      {
		struct nRGB* nam;
		nam = bsearch( (void*)((UINT)data >> 8), NamedRGB,
			       SIZEOF(NamedRGB), sizeof(*NamedRGB), nRGBcmp );
		if (nam != NULL)
		{
		  outputf( "\\c%s", nam->name );
		}
		else
		{
		  BYTE r, g, b;
		  r = swap_nybbles( (BYTE)(data >> 8) );
		  g = swap_nybbles( (BYTE)(data >> 16) );
		  b = swap_nybbles( (BYTE)(data >> 24) );
		  outputf( "\\c%.2X%.2X%.2X", r, g, b );
		}
	      }
	    }
	  }
	}
      }
      else
      {
      bad_tag:
	buffer[buflen++] = '\\';
	in_tag = true;
	goto keep_tag;
      }
      txt += tag;
      len -= tag;
    }
    else
    {
    keep_tag:
      do
      {
	if (!in_text && !in_tag)
	{
	  ++txt;
	  --len;
	  continue;
	}
	if (indented)
	{
	  if (*txt == ' ')
	    buffer[buflen++] = '\\';
	  indented = false;
	}
	if (*txt >= 0x100)
	{
	  if (!unicode)
	  {
	    UCHAR ch;
	    BOOL  def;
	    WideCharToMultiByte( CP_ACP, WC_NO_BEST_FIT_CHARS, txt, 1, &ch, 1,
				 NULL, &def );
	    if (def)
	    {
	      if ((*txt >= L'\x2081' && *txt <= L'\x2083') ||
		  *txt == L'\x2070' || (*txt >= L'\x2074' && *txt <= L'\x2079'))
		buflen += swprintf( buffer+buflen, L"\\%c", '0' + (*txt & 15) );
	      else
		buflen += swprintf( buffer+buflen, L"\\x%.4X", *txt );
	    }
	    else
	    {
	      buffer[buflen++] = ch;
	      ++txt;
	      --len;
	      continue;
	    }
	  }
	  else
	  {
	    buffer[buflen++] = *txt;
	  }
	  ++txt;
	  --len;
	  // Simple test for letters or ideographs.  Let, for example, Greek &
	  // Cyrillic continue, but treat each ideograph separately.
	  if (txt[-1] < 0x1000)
	    continue;
	  break;
	}
	if (in_text)
	{
	  if (*txt == '\\' || *txt == '{')
	  {
	    buffer[buflen++] = '\\';
	  }
	  else if (*txt == '&' && rdl)
	  {
	    if (WCSBEG( txt+1, L"lt;" ))
	    {
	      buffer[buflen++] = '<';
	      txt += 4;
	      len -= 4;
	      continue;
	    }
	    if (WCSBEG( txt+1, L"gt;" ))
	    {
	      buffer[buflen++] = '>';
	      txt += 4;
	      len -= 4;
	      continue;
	    }
	    if (WCSBEG( txt+1, L"amp;" ))
	    {
	      buffer[buflen++] = '&';
	      txt += 5;
	      len -= 5;
	      continue;
	    }
	    buffer[buflen++] = '\\';
	  }
	}
	buffer[buflen++] = *txt;
	if (in_tag && *txt == '>')
	  in_tag = false;
	++txt;
	--len;
      } while (len != 0 && *txt != ' ' && *txt != '<' && *txt != '\n');
      // Prefer trailing spaces to escaped leading spaces.
      space = (buffer[buflen-1] == ' ');
      while (len != 0 && *txt == ' ')
      {
	space = true;
	buffer[buflen++] = ' ';
	++txt;
	--len;
      }
      buffer[buflen] = '\0';
      outputS( buffer );
    }
  }

  // Ends with a space, or RDL does NOT end with PARA, so add the terminator.
  if (space || !para)
    outputs( "\\." );
}


void outputS( LPCWSTR s )
{
  int len = wcslen( s );
  if (col + len >= width)
  {
    outputn( true );
    if (*s == ' ')
      outputc( '\\' );
  }
  col += len;

  if (unicode)
  {
    fputws( s, out );
  }
  else
  {
    for (; *s; ++s)
      putc( *s, out );
  }
}


void outputs( LPCSTR s )
{
  int len = strlen( s );
  if (col + len >= width)
  {
    outputn( true );
    if (*s == ' ')
      outputc( '\\' );
  }
  col += len;

  if (unicode)
  {
    for (; *s; ++s)
    {
      putc( *s, out );
      putc( '\0', out );
    }
  }
  else
  {
    fputs( s, out );
  }
}


void outputf( LPCSTR fmt, ... )
{
  char	  buf[256];
  va_list args;

  va_start( args, fmt );
  _vsnprintf( buf, sizeof(buf), fmt, args );
  va_end( args );

  outputs( buf );
}


void outputc( int c )
{
  putc( c, out );
  if (unicode)
    putc( '\0', out );

  ++col;
}


void outputn( bool ind )
{
  if (ind)
    outputc( '\\' );

  outputc( '\r' );
  outputc( '\n' );
  col = 0;

  if (ind)
    indent();
}


void indent( void )
{
  blank_line = true;

  if (!HTML)
  {
    if (margin <= -9)
    {
      outputc( '\t' );
      col = -margin;
    }
    else if (margin <= 9)
      outputs( "         " );
    else
      outputf( "%*c", margin, ' ' );
  }
  else
  {
    if (margin < 0)
    {
      outputc( '\t' );
      col = -margin;
    }
    else
    {
      outputf( "%*c", margin, ' ' );
    }
  }
}


// Retrieve a string resource, returning a pointer to it and storing its length
// in LEN.  If the resource does not exist, returns NULL and LEN is set to 0.
LPCWSTR GetString( HMODULE mod, UINT id, int* len )
{
  LPCWSTR mem;
  HRSRC   rsrc;
  HGLOBAL res;

  mem  = NULL;
  *len = 0;

  rsrc = FindResourceEx( mod, RT_STRING, MAKEINTRESOURCE( (id >> 4) + 1 ), 0 );
  if (rsrc != NULL)
  {
    res = LoadResource( mod, rsrc );
    if (res != NULL)
    {
      mem = LockResource( res );
      if (mem != NULL)
      {
	for (id &= 0x0f;; --id)
	{
	  *len = *mem;
	  if (id == 0)
	    break;
	  mem += *len + 1;
	}
	if (*len == 0)
	  mem = NULL;
	else
	  ++mem;
      }
    }
  }

  return mem;
}


// Retrieve an HTML (XML/RDL) resource, returning a pointer to it and storing
// its length in LEN.  If the resource does not exist, returns NULL and LEN is
// set to 0.
LPCWSTR GetHTML( HMODULE mod, UINT id, int* len )
{
  LPCWSTR mem;
  HRSRC   rsrc;
  HGLOBAL res;

  mem  = NULL;
  *len = 0;

  rsrc = FindResourceEx( mod, RT_HTML, MAKEINTRESOURCE( id ), 0 );
  if (rsrc != NULL)
  {
    res = LoadResource( mod, rsrc );
    if (res != NULL)
    {
      mem = LockResource( res );
      if (mem != NULL)
	*len = SizeofResource( mod, rsrc ) >> 1;
    }
  }

  return mem;
}


// Retrieve the language of a resource.  Only the first is used.
BOOL CALLBACK GetLanguage( HANDLE hModule, LPCTSTR lpszType, LPCTSTR lpszName,
			   WORD wIDLanguage, long lParam )
{
  lang = wIDLanguage;

  if (lang != 1033)
  {
    outputf( "L %d", lang );
    outputn( false );
    outputn( false );
  }

  return FALSE;
}
