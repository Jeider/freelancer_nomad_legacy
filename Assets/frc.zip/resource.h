/*
  resource.h - Resource handling.

  Jason Hood, 6 June, 2010.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

extern WORD langid;
extern int  update;

int  AddResource( BOOL, int, LPWSTR, int, int* );
BOOL WriteResources( LPCSTR );
