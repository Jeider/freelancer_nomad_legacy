/*
  file.c - File reading routines.

  Jason Hood, 6 June, 2010.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

BOOL unicode;
int  line_num;

static int    max_len;
static LPWSTR line;


// Open NAME for reading.  Returns NULL if failed, otherwise the FILE pointer.
// Sets UNICODE accordingly and LINE_NUM to 0.
FILE* Open( LPCSTR name )
{
  FILE* file;

  file = fopen( name, "rb" );
  if (file != NULL)
  {
    // Read the first two bytes to determine type.
    int b1 = getc( file );
    int b2 = getc( file );

    // Can't contain anything useful if there's not even two characters.
    if (b2 == EOF)
    {
      fclose( file );
      file = NULL;
    }
    else
    {
      // Say a file is Unicode if it starts with the marker (little-endian) or
      // the second byte is 0 (since the first thing must be ASCII).
      if (b1 == 0xFF && b2 == 0xFE)
      {
	unicode = TRUE;
      }
      else if (b2 == 0)
      {
	unicode = TRUE;
	rewind( file );
      }
      else
      {
	unicode = FALSE;
	rewind( file );
      }
      line_num = 0;
    }
  }

  return file;
}


// Read a character from the file.
int GetChar( FILE* file )
{
  int b1, b2;

  b1 = getc( file );
  if (b1 == EOF)
    return EOF;

  if (unicode)
  {
    b2 = getc( file );
    if (b2 == EOF)
      b2 = 0;
    return (b1 | (b2 << 8));
  }

  b2 = 0;
  MultiByteToWideChar( CP_ACP, 0, (LPSTR)&b1, 1, (LPWSTR)&b2, 1 );
  return b2;
}


// Read a line from the file.  Returns a pointer to the line (modified on each
// call), or NULL if there are no more lines.
LPWSTR GetLine( FILE* file )
{
  int ch;
  int len;

  ++line_num;
  for (len = 0;;)
  {
    ch = GetChar( file );
    if (ch == EOF || ch == '\n')
      break;
    if (ch == '\r')
      continue;
    if (len >= max_len)
    {
      max_len += 80;
      // Just assume there's enough memory.
      line = realloc( line, max_len * 2 );
    }
    line[len++] = ch;
  }

  if (len >= max_len)
  {
    max_len += 80;
    line = realloc( line, max_len * 2 );
  }
  line[len] = '\0';

  return (ch == EOF && len == 0) ? NULL : line;
}
