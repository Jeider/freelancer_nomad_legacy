/*
  frc.c - Freelancer Resource Compiler

  Jason Hood, 6 June to 11 July, 2010.

  v1.10, 1 to 8 May, 2012.
  v1.11, 3 February, 2024.

  A simple resource compiler tailored to Freelancer's RDL format.  If the file
  starts with the UTF-16 BOM, or the second byte is NUL, it is taken as Unicode,
  otherwise ANSI (Windows-1252).  Line comments begin with ';', but only after a
  space; block comments begin with ";+" and end with ";-", but only at the
  beginning of a line and not within text.  The first line is "L id" (no leading
  spaces) to specify the resource language identifier (default is 1033 - English
  (US)).  Then it is either "S id" or "H id" to create a string (name) or HTML
  (infocard) resource.	Identifiers must be unique; only the low 16 bits are
  used.  HTML resources automatically start with "\xfeff<RDL><PUSH/>" and end
  with "<POP/></RDL>"; start with '~' to prevent this, or to do it for strings.
  Tabs are converted to two spaces; newlines are honored, as is "\n"; "\xHHHH"
  can be used to specify a Unicode character; "\N" is a subscript digit ("1",
  "2" or "3") or superscript (the others); trailing space or backslash can be
  used to join lines (within text only); "\." will stop a line (to allow for
  trailing spaces, or to prevent "<PARA/>" being added to RDL).  The following
  sequences are used to represent RDL:

	\b	  <TRA bold="true"/>
	\B	  <TRA bold="false"/>
	\cC	  <TRA color="#RRGGBB"/>    lower case
	\cName	  <TRA color="#RRGGBB"/>    match case
	\cRRGGBB  <TRA color="#RRGGBB"/>    upper case
	\C	  <TRA color="default"/>
	\fN	  <TRA font="N"/>           one or two digits
	\F	  <TRA font="default"/>
	\hN	  <POS h="N" relH="true"/>  one to three digits
	\i	  <TRA italic="true"/>
	\I	  <TRA italic="false"/>
	\l	  <JUST loc="l"/>           left
	\m	  <JUST loc="c"/>           center (middle)
	\n	  <PARA/>
	\r	  <JUST loc="r"/>           right
	\u	  <TRA underline="true"/>
	\U	  <TRA underline="false"/>

	Name	  RRGGBB	    C	RRGGBB	  C may be prefixed with:
	----	  ------	    -	------
	Gray	  808080	    z	000000	  d to use 40 (dark)
	Blue	  4848E0	    r	FF0000	  h to use 80 (half)
	Green	  3BBF1D	    g	00FF00	  l to use C0 (light)
	Aqua	  87C3E0	    b	0000FF
	Red	  BF1D1D	    c	00FFFF
	Fuchsia   8800C2	    m	FF00FF
	Yellow	  F5EA52	    y	FFFF00
	White	  FFFFFF	    w	FFFFFF

  TRA sequences may alternatively be enclosed in braces: "\b{bold}" is exactly
  equivalent to "\bbold\B".


  Examples:

	FRC		     RC string
	---		     ---------
	S 1  some text	     "some text"
	S 2  \ spacing \.    " spacing "
	S 3  one \	     "one line"
	     line
	S 4  two\nlines      "two\nlines"
	S 5  two	     "two\nlines"
	     lines
	S 6  ~ Info	     "<RDL><PUSH/><TEXT>Info</TEXT><PARA/><POP/></RDL>"
	S 7		     "Separate line"
	     Separate line

	H 8  RDL	     "\xFEFF<RDL><PUSH/><TEXT>RDL</TEXT><PARA/><POP/></RDL>"
	H 9  Rumor\.	     "\xFEFF<RDL><PUSH/><TEXT>Rumor</TEXT><POP/></RDL>"
	H 10 ~ Name	     "Name"
	H 11			     \xFEFF<RDL><PUSH/>
	     Battleship \i{Osiris}.  <TEXT>Battleship </TEXT>
				     <TRA italic="true"/><TEXT>Osiris</TEXT>
				     <TRA italic="false"/><TEXT>.</TEXT><PARA/>
				     <POP/></RDL>
*/

#define PVERS "1.11"
#define PDATE "3 February, 2024"

#include "file.h"
#include "resource.h"
#include "blankdll.h"
#include <stdlib.h>
#include <stdarg.h>
#include <wchar.h>
#include <conio.h>

#define STREQ( s1, s2 ) (strcmp( s1, s2 ) == 0)
#define SPACE( c )	((c) == ' ' || (c) == '\t')
#define DIGIT( c )	((c) >= '0' && (c) <= '9')

#define SIZEOF(a)	(sizeof(a)/sizeof(*(a)))


#define E_OK	 0
#define E_IN	 1
#define E_OUT	 2
#define E_SYNTAX 3
#define E_ID	 4


BOOL create;

int Process( LPCSTR, LPCSTR );
int ReadId( LPWSTR* );
int ReadText( BOOL, LPWSTR, FILE*, LPCSTR );
int ProcessString( LPWSTR, FILE*, LPCSTR );
int ProcessRDL( LPWSTR, FILE*, LPCSTR );

LPCSTR split( LPCSTR, LPCSTR* );


int main( int argc, char* argv[] )
{
  if (argc == 1 || STREQ( argv[1], "/?" ) || STREQ( argv[1], "-?" )
		|| STREQ( argv[1], "--help" ))
  {
    BOOL gui = FALSE;
    if (argc == 1)
    {
      // Simple test to see if we were run from a GUI window.
      CONSOLE_SCREEN_BUFFER_INFO csbi;
      if (GetConsoleScreenBufferInfo( GetStdHandle( STD_OUTPUT_HANDLE ), &csbi )
	  && csbi.dwCursorPosition.X == 0 && csbi.dwCursorPosition.Y == 0)
      {
	gui = TRUE;
      }
    }
    puts( "FRC by Jason Hood <jadoxa@yahoo.com.au>.\n"
	  "Version " PVERS " (" PDATE ").\n"
	  "http://freelancer.adoxa.vze.com/\n"
	  "\n"
	  "Compile Freelancer string (name) and HTML (infocard) resources.\n"
	  "\n"
	  "frc [-cN] infile [outfile]\n"
	  "\n"
	  "-c\tcreate OUTFILE instead of updating\n"
	  "-N\tupdate every N kilobytes\n"
	  "infile\tgenerate OUTFILE[.dll] from INFILE[.frc]\n"
	  "\n"
	  "Create will use OUTFILE_blank.dll (from the same path as INFILE) if it exists."
	);
    if (gui)
    {
      puts( "\nPress any key to exit (try running from Command Prompt)." );
      while (_kbhit()) _getch();
      _getch();
    }
    return E_OK;
  }
  if (STREQ( argv[1], "--version" ))
  {
    puts( "FRC version " PVERS " (" PDATE ")." );
    return E_OK;
  }

  while (argv[1][0] == '-')
  {
    while (*++argv[1])
    {
      if (*argv[1] == 'c')
	create = TRUE;
      else if (isdigit( *argv[1] ))
      {
	char* end;
	update = strtol( argv[1], &end, 0 ) * 1000;
	argv[1] = end - 1;
      }
      else
      {
	fprintf( stderr, "Unknown option: %c.\n", *argv[1] );
	return E_SYNTAX;
      }
    }
    ++argv;
    if (argv[1] == NULL)
      return E_OK;
  }

  return Process( argv[1], argv[2] );
}


// Given a path, return a pointer to the name, setting EXT to the extension.
LPCSTR split( LPCSTR path, LPCSTR* ext )
{
  LPCSTR name;

  if (ext != NULL)
    *ext = NULL;

  for (name = path; *path != '\0'; ++path)
  {
    if (*path == '/' || *path == '\\')
      name = path + 1;
    else if (ext != NULL && *path == '.')
      *ext = path;
  }
  if (ext != NULL)
    if (*ext == NULL || *ext <= name)
      *ext = path;

  return name;
}


// Compile IN to OUT.
int Process( LPCSTR in, LPCSTR out )
{
  LPCSTR name, ext;
  char	 inname[MAX_PATH], outname[MAX_PATH];
  FILE*  fin;
  LPWSTR line;
  int	 id, rc;
  BOOL	 created;
  int	 lang_line, com_line;

  fin = Open( in );
  if (fin == NULL)
  {
    _snprintf( inname, MAX_PATH, "%s.frc", in );
    fin = Open( inname );
    if (fin == NULL)
    {
      fprintf( stderr, "Could not open \"%s\".\n", inname );
      return E_IN;
    }
    in = inname;
  }

  if (out == NULL)
  {
    name = split( in, &ext );
    if (*ext == '\0')
      _snprintf( outname, MAX_PATH, "%s.dll", in );
    else
      _snprintf( outname, MAX_PATH, "%.*s.dll", ext - in, in );
    out = outname;
  }
  else
  {
    int len = strlen( out );
    if (len <= 4 || stricmp( out + len - 4, ".dll" ) != 0)
    {
      _snprintf( outname, MAX_PATH, "%s.dll", out );
      out = outname;
    }
  }

  // Create a blank DLL if the output file doesn't exist.
  created = FALSE;
  if (create || GetFileAttributes( out ) == -1)
  {
    FILE*  fout;
    LPCSTR oname;
    char   blank[MAX_PATH];

    // Check if IN\OUT_blank.dll exists.
    name = split( in, NULL );
    oname = split( out, &ext );
    _snprintf( blank, MAX_PATH, "%.*s%.*s_blank.dll",
				name - in, in, ext - oname, oname );
    if (GetFileAttributes( blank ) == -1)
    {
      fout = fopen( out, "wb" );
      if (fout == NULL)
      {
	fprintf( stderr, "Unable to create \"%s\".\n", out );
	fclose( fin );
	return E_OUT;
      }
      fwrite( Blank_DLL, sizeof(Blank_DLL), 1, fout );
      fclose( fout );
    }
    else if (!CopyFile( blank, out, FALSE ))
    {
      fprintf( stderr, "Unable to copy \"%s\" to \"%s\".\n", blank, out );
      return E_OUT;
    }
    else
    {
      // Remove the "Relocations stripped" characteristic, as generating a
      // fixed DLL is easier to manage.
      char buf[1024], *pe;
      int  len;
      fout = fopen( out, "rb+" );
      len = fread( buf, 1, 1024, fout );
      pe = buf + *(PDWORD)(buf + 0x3c);
      if (*(PSHORT)(pe + 0x16) == 0x210F)
      {
	pe[0x16] = 0x0E;
	rewind( fout );
	fwrite( buf, 1, 1024, fout );
      }
      fclose( fout );
    }
    created = TRUE;
  }

  lang_line = com_line = 0;
  while ((line = GetLine( fin )) != NULL)
  {
    if (*line == '\0')
      continue;
    if (*line == ';')
    {
      if (com_line != 0)
      {
	if (line[1] == '-')
	  com_line = 0;
      }
      else if (line[1] == '+')
	com_line = line_num;
      continue;
    }
    if (com_line != 0)
      continue;

    if (!SPACE( line[1] ))
    {
      fprintf( stderr, "%s:%d: Syntax error.\n", in, line_num );
      fclose( fin );
      return E_SYNTAX;
    }
    if (*line == 'L')
    {
      if (lang_line != 0)
      {
	fprintf( stderr, "%s:%d: Only one language allowed (see line %d).\n",
			 in, line_num, lang_line );
	fclose( fin );
	return E_ID;
      }
      id = ReadId( &line );
      if (id < 0 || id > 65535)
      {
	fprintf( stderr, "%s:%d: Expecting language identifier.\n",
			 in, line_num );
	fclose( fin );
	return E_ID;
      }
      langid = (WORD)id;
      lang_line = line_num;
    }
    else if (*line == 'S' || *line == 'H')
    {
      rc = ReadText( (*line == 'H'), line, fin, in );
      if (rc != E_OK)
      {
	fclose( fin );
	return rc;
      }
    }
    else
    {
      fprintf( stderr, "%s:%d: Syntax error.\n", in, line_num );
      fclose( fin );
      return E_SYNTAX;
    }
  }

  fclose( fin );

  if (com_line != 0)
  {
    fprintf( stderr, "%s:%d: Warning: comment not closed.\n", in, com_line );
  }

  if (!WriteResources( out ))
  {
    fprintf( stderr, "Could not %s \"%s\".\n",
		     (created) ? "create" : "update", out );
    return E_OUT;
  }

  return E_OK;
}


// Read the identifier from the line, updating LINE to the next token.	LINE
// is assumed to be pointing to the command.  Returns -1 if invalid number,
// LINE unchanged.
int ReadId( LPWSTR* line )
{
  LPWSTR end;
  int	 id;

  id = wcstol( *line + 2, &end, 0 );
  if ((*end != '\0' && !SPACE( *end )) || end == *line + 2)
    return -1;

  for (; SPACE( *end ); ++end)
    ;

  *line = end;
  return id;
}


LPWSTR text;
int    tlen, tmax;

void AddString( LPCWSTR s, int len )
{
  if (len < 0)
    len = wcslen( s );
  if (len == 0)
    return;

  if (tlen + len > tmax)
  {
    tmax = tlen + len;
    // Round to the next power of 2, assuming < 65536.
    tmax |= tmax >> 1;
    tmax |= tmax >> 2;
    tmax |= tmax >> 4;
    tmax |= tmax >> 8;
    ++tmax;
    text = realloc( text, tmax * 2 );
  }

  memcpy( text + tlen, s, len * 2 );
  tlen += len;
}


void AddChar( int c )
{
  if (tlen < tmax)
    text[tlen++] = c;
  else
    AddString( (LPCWSTR)&c, 1 );
}


void AddFormat( LPCWSTR fmt, ... )
{
  WCHAR   buf[256];
  int	  len;
  va_list args;

  va_start( args, fmt );
  len = _vsnwprintf( buf, SIZEOF(buf), fmt, args );
  va_end( args );

  AddString( buf, len );
}




// Read a resource.
int ReadText( BOOL html, LPWSTR line, FILE* fin, LPCSTR in )
{
  int  id;
  int  err, rc;
  BOOL rdl;

  id = ReadId( &line );
  if (id == -1)
  {
    fprintf( stderr, "%s:%d: Expecting %s identifier.\n", in, line_num,
		     (html) ? "info" : "name" );
    return E_SYNTAX;
  }

  tlen = 0;
  if (html)
    AddChar( L'\xFEFF' );
  rdl = html;
  for (;; ++line)
  {
    if (*line == '^')
      ; // do nothing
    else if (*line == '~')
      rdl ^= 1;
    else
    {
      while (SPACE( *line ))
	++line;
      break;
    }
  }

  if (rdl)
  {
    AddString( L"<RDL><PUSH/>", -1 );
    rc = ProcessRDL( line, fin, in );
    AddString( L"<POP/></RDL>", -1 );
  }
  else
  {
    rc = ProcessString( line, fin, in );
  }

  if (rc != E_OK)
    return rc;

  err = line_num;
  rc = AddResource( html, id, text, tlen, &err );
  if (rc != 0)
  {
    fprintf( stderr, "%s:%d: %s %s %d (see line %d).\n",
		     in, line_num,
		     ((rc == 1 && !html) || (rc == 2 && html))
		     ? "Redefining" : "Shadowing",
		     (rc == 1) ? "name" : "info",
		     id, err );
    return E_ID;
  }

  return E_OK;
}


void TrimComment( LPWSTR line )
{
  LPWSTR nul;

  if (*line == ';')
  {
    *line = '\0';
    return;
  }

  for (;;)
  {
    while (!SPACE( *line ))
    {
      if (*line == '\0')
	return;
      ++line;
    }
    nul = line;
    do ++line; while (SPACE( *line ));
    if (*line == ';')
    {
      *nul = '\0';
      return;
    }
  }
}


int ProcessString( LPWSTR line, FILE* fin, LPCSTR in )
{
  LPWSTR start;
  long	 pos;
  int	 blanks;

  TrimComment( line );
  for (blanks = (*line != '\0');; blanks = 1)
  {
    for (start = line; *line != '\0'; ++line)
    {
      if (*line == '\\')
      {
	if (line[1] == '\0')
	{
	  blanks = 0;
	  break;
	}
	AddString( start, line - start );
	if (line[1] == '.')
	{
	  return E_OK;
	}
	if (line[1] == 'n')
	{
	  AddChar( '\n' );
	  ++line;
	  start = line + 1;
	}
	else if (line[1] == 'x')
	{
	  wchar_t hex;
	  int	  digits;
	  line += 2;
	  if (!iswxdigit( *line ))
	  {
	    fprintf( stderr, "%s:%d: Expecting hex digit.\n", in, line_num );
	    return E_SYNTAX;
	  }
	  hex = 0;
	  digits = 0;
	  do
	  {
	    hex = hex * 16 + ((*line > '9') ? (*line | 0x20) - 'a' + 10
					    : *line - '0');
	    ++line;
	  } while (++digits < 4 && iswxdigit( *line ));
	  AddChar( hex );
	  start = line--;
	}
	else
	{
	  start = ++line;
	}
      }
      else if (*line == '\t')
      {
	AddString( start, line - start );
	AddString( L"  ", 2 );
	start = line + 1;
      }
    }
    AddString( start, line - start );
    if (text[tlen-1] == ' ')
      blanks = 0;

    for (;; ++blanks)
    {
      pos = ftell( fin );
      line = GetLine( fin );
      if (line == NULL)
      {
	return E_OK;
      }
      if (!SPACE( *line ) && *line != '\0')
      {
	--line_num;
	fseek( fin, pos, SEEK_SET );
	return E_OK;
      }
      while (SPACE( *line ))
	++line;
      if (*line == ';')
      {
	--blanks;
	continue;
      }
      TrimComment( line );
      if (*line == '\0' || (*line == '\\' && line[1] == '\0'))
	continue;

      while (--blanks >= 0)
	AddChar( '\n' );
      break;
    }
  }
}


enum { TRA_bold      = 0x01,
       TRA_italic    = 0x02,
       TRA_underline = 0x04,
       TRA_font      = 0xF8,
       TRA_color     = 0xFFFFFF00
     };

enum {	       TAG_none,
       /* b */ TAG_bold,
       /* B */ TAG_bold_def,
       /* c */ TAG_color,
       /* C */ TAG_color_def,
       /* f */ TAG_font,
       /* F */ TAG_font_def,
       /* i */ TAG_italic,
       /* I */ TAG_italic_def,
       /* u */ TAG_underline,
       /* U */ TAG_underline_def,
	       TAG_TRA,
       /* l */ TAG_left = 'l',
       /* m */ TAG_center = 'c',
       /* r */ TAG_right = 'r',
       /* h */ TAG_posh = 'h',
     };

struct TColors
{
  LPCWSTR name;
  int	  rgb;
}
Colors[] =
{
  { L"Gray",    0x808080 },
  { L"Blue",    0xE04848 },
  { L"Green",   0x1DBF3B },
  { L"Aqua",    0xE0C387 },
  { L"Red",     0x1D1DBF },
  { L"Fuchsia", 0xC20088 },
  { L"Yellow",  0x52EAF5 },
  { L"White",   0xFFFFFF },
};


BOOL in_text, in_tag;
int  in_tra, in_just;
int  in_font = -1, in_col = -1;
int  tra_data, tra_mask, tra_def;
int  tra_cnt;
#define TAG_STK 8
int  tag_stk[TAG_STK], tag_top;


BYTE swap_nybbles( BYTE b )
{
  return (b >> 4) | (b << 4);
}


void AddTRA( void )
{
  if (tra_mask != 0)
  {
    AddString( L"<TRA", 4 );
    if (tra_cnt <= 2)
    {
      if (tra_mask & TRA_bold)
      {
	AddFormat( L" bold=\"%s\"",
		   ((tra_def & TRA_bold) || !(tra_data & TRA_bold))
		   ? L"false" : L"true" );
      }
      if (tra_mask & TRA_italic)
      {
	AddFormat( L" italic=\"%s\"",
		   ((tra_def & TRA_italic) || !(tra_data & TRA_italic))
		   ? L"false" : L"true" );
      }
      if (tra_mask & TRA_underline)
      {
	AddFormat( L" underline=\"%s\"",
		   ((tra_def & TRA_underline) || !(tra_data & TRA_underline))
		   ? L"false" : L"true" );
      }
      if (tra_mask & TRA_font)
      {
	if (tra_def & TRA_font)
	  AddString( L" font=\"default\"", -1 );
	else
	  AddFormat( L" font=\"%d\"", (BYTE)(tra_data >> 3) + 1 );
      }
      if (tra_mask & TRA_color)
      {
	if (tra_def & TRA_color)
	  AddString( L" color=\"default\"", -1 );
	else
	{
	  BYTE r, g, b;
	  r = swap_nybbles( (BYTE)(tra_data >> 8) );
	  g = swap_nybbles( (BYTE)(tra_data >> 16) );
	  b = swap_nybbles( (BYTE)(tra_data >> 24) );
	  AddFormat( L" color=\"#%.2X%.2X%.2X\"", r, g, b );
	}
      }
    }
    else
    {
      if (tra_data != 0)
	AddFormat( L" data=\"%d\"", tra_data );
      AddFormat( L" mask=\"%d\"", tra_mask );
      if (tra_def != 0)
	AddFormat( L" def=\"%d\"", tra_def );
    }
    AddString( L"/>", 2 );
    tra_data = tra_mask = tra_def = 0;
    tra_cnt = 0;
  }
}


void AddText( LPWSTR text, int len )
{
  if (len > 0)
  {
    if (!in_text)
    {
      AddTRA();
      if (!in_tag)
      {
	AddString( L"<TEXT>", 6 );
	in_text = TRUE;
      }
    }
    AddString( text, len );
  }
}


void DoneText( void )
{
  if (in_text)
  {
    AddString( L"</TEXT>", 7 );
    in_text = FALSE;
  }
}


int is_tag( WCHAR t )
{
  switch (t)
  {
    case 'b': return TAG_bold;
    case 'c': return TAG_color;
    case 'f': return TAG_font;
    case 'i': return TAG_italic;
    case 'u': return TAG_underline;

    case 'B': return TAG_bold_def;
    case 'C': return TAG_color_def;
    case 'F': return TAG_font_def;
    case 'I': return TAG_italic_def;
    case 'U': return TAG_underline_def;

    case 'l': return TAG_left;
    case 'm': return TAG_center;
    case 'r': return TAG_right;

    case 'h': return TAG_posh;

    default:  return TAG_none;
  }
}


BOOL check_tag( int tag, LPWSTR* line, LPCSTR in )
{
  LPWSTR tags;
  int	 i;

  DoneText();

  tags = *line + 2;
  if (tag < TAG_TRA)
  {
    switch (tag)
    {
      case TAG_bold:
	if (!(in_tra & TRA_bold))
	{
	  in_tra   |= TRA_bold;
	  tra_data |= TRA_bold;
	  tra_mask |= TRA_bold;
	  ++tra_cnt;
	}
      break;

      case TAG_italic:
	if (!(in_tra & TRA_italic))
	{
	  in_tra   |= TRA_italic;
	  tra_data |= TRA_italic;
	  tra_mask |= TRA_italic;
	  ++tra_cnt;
	}
      break;

      case TAG_underline:
	if (!(in_tra & TRA_underline))
	{
	  in_tra   |= TRA_underline;
	  tra_data |= TRA_underline;
	  tra_mask |= TRA_underline;
	  ++tra_cnt;
	}
      break;

      case TAG_bold_def:
	if (in_tra & TRA_bold)
	{
	  in_tra   &= ~TRA_bold;
	  tra_def  |= TRA_bold;
	  tra_mask |= TRA_bold;
	  ++tra_cnt;
	}
      break;

      case TAG_italic_def:
	if (in_tra & TRA_italic)
	{
	  in_tra   &= ~TRA_italic;
	  tra_def  |= TRA_italic;
	  tra_mask |= TRA_italic;
	  ++tra_cnt;
	}
      break;

      case TAG_underline_def:
	if (in_tra & TRA_underline)
	{
	  in_tra   &= ~TRA_underline;
	  tra_def  |= TRA_underline;
	  tra_mask |= TRA_underline;
	  ++tra_cnt;
	}
      break;

      case TAG_font:
	if (!DIGIT( *tags ))
	{
	  fprintf( stderr, "%s:%d: Expecting number after 'f'.\n", in, line_num );
	  return FALSE;
	}
	i = *tags++ - '0';
	if (DIGIT( *tags ))
	  i = i * 10 + *tags++ - '0';
	--i;
	if (in_font != i)
	{
	  in_font   = i;
	  tra_data |= i << 3;
	  tra_mask |= TRA_font;
	  ++tra_cnt;
	}
      break;

      case TAG_font_def:
	if (in_font != -1)
	{
	  in_font   = -1;
	  tra_def  |= TRA_font;
	  tra_mask |= TRA_font;
	  ++tra_cnt;
	}
      break;

      case TAG_color:
	if (!iswlower( tags[0] ))
	{
	  if (iswlower( tags[1] ))
	  {
	    for (i = SIZEOF(Colors); --i >= 0;)
	    {
	      if (*tags == *Colors[i].name)
	      {
		int len = wcslen( Colors[i].name );
		if (wcsncmp( tags + 1, Colors[i].name + 1, len - 1 ) == 0)
		{
		  tags += len;
		  i = Colors[i].rgb;
		  break;
		}
	      }
	    }
	    if (i < 0)
	    {
	      fprintf( stderr, "%s:%d: Unrecognized color name.\n", in, line_num );
	      return FALSE;
	    }
	  }
	  else
	  {
	    for (i = 0; i < 6; ++i)
	    {
	      if (!iswxdigit( tags[i] ))
	      {
		fprintf( stderr, "%s:%d: Color expecting six hex digits.\n", in, line_num );
		return FALSE;
	      }
	    }
	    swscanf( tags, L"%6X", &i );
	    i = ((BYTE)i << 16) | (i & 0xFF00) | (i >> 16);
	    tags += 6;
	  }
	}
	else
	{
	  i = 0xFF;
	  switch (*tags)
	  {
	    case 'd': i = 0x40; ++tags; break;
	    case 'h': i = 0x80; ++tags; break;
	    case 'l': i = 0xC0; ++tags; break;
	  }
	  switch (*tags++)
	  {
	    case 'z': i = 0;        break;

	    case 'r': i <<=  0;     break;
	    case 'g': i <<=  8;     break;
	    case 'b': i <<= 16;     break;

	    case 'c': i |= i << 8;
		      i <<= 8;	    break;
	    case 'm': i |= i << 16; break;
	    case 'y': i |= i << 8;  break;

	    case 'w': i |= (i << 8) | (i << 16); break;

	    default:
	      fprintf( stderr, "%s:%d: Unrecognized color.\n", in, line_num );
	      return FALSE;
	  }
	}
	if (in_col != i)
	{
	  in_col    = i;
	  tra_data |= i << 8;
	  tra_mask |= TRA_color;
	  ++tra_cnt;
	}
      break;

      case TAG_color_def:
	if (in_col != -1)
	{
	  in_col    = -1;
	  tra_def  |= TRA_color;
	  tra_mask |= TRA_color;
	  ++tra_cnt;
	}
      break;
    }
  }
  else if (tag == TAG_posh)
  {
    if (!DIGIT( *tags ))
    {
      fprintf( stderr, "%s:%d: Expecting number after 'h'.\n", in, line_num );
      return FALSE;
    }
    i = *tags++ - '0';
    if (DIGIT( *tags ))
    {
      i = i * 10 + *tags++ - '0';
      if (DIGIT( *tags ))
	i = i * 10 + *tags++ - '0';
    }
    AddTRA();
    AddFormat( L"<POS h=\"%d\" relH=\"true\"/>", i );
  }
  else
  {
    if (in_just != tag)
    {
      in_just = tag;
      AddTRA();
      AddFormat( L"<JUST loc=\"%c\"/>", tag );
    }
  }

  *line = tags;
  return TRUE;
}


int ProcessRDL( LPWSTR line, FILE* fin, LPCSTR in )
{
  LPWSTR start;
  long	 pos;
  int	 blanks;
  int	 tag;

  in_text = in_tag = 0;
  in_tra = in_just = 0;
  in_font = in_col = -1;
  tra_data = tra_mask = tra_def = 0;
  tra_cnt = 0;
  
  TrimComment( line );
  in_tag = FALSE;
  for (blanks = (*line != '\0');; blanks = 1)
  {
    for (start = line; *line != '\0'; ++line)
    {
      if (*line == '\\')
      {
	if (line[1] == '\0')
	{
	  blanks = 0;
	  break;
	}
	AddText( start, line - start );
	if (line[1] == '.')
	{
	  blanks = 0;
	  goto finished;
	}
	if (line[1] == '<')
	{
	  DoneText();
	  in_tag = TRUE;
	  start = ++line;
	}
	else if (line[1] == 'n')
	{
	  DoneText();
	  AddTRA();
	  AddString( L"<PARA/>", 7 );
	  ++line;
	  start = line + 1;
	}
	else if (DIGIT( line[1] ))
	{
	  wchar_t script;
	  ++line;
	  script = ((*line >= '1' && *line <= '3') ? L'\x2080' : L'\x2070')
		   + *line - '0';
	  AddText( &script, 1 );
	  start = line + 1;
	}
	else if (line[1] == 'x')
	{
	  wchar_t hex;
	  int	  digits;
	  line += 2;
	  if (!iswxdigit( *line ))
	  {
	    fprintf( stderr, "%s:%d: Expecting hex digit.\n", in, line_num );
	    return E_SYNTAX;
	  }
	  hex = 0;
	  digits = 0;
	  do
	  {
	    hex = hex * 16 + ((*line > '9') ? (*line | 0x20) - 'a' + 10
					    : *line - '0');
	    ++line;
	  } while (++digits < 4 && iswxdigit( *line ));
	  AddText( &hex, 1 );
	  start = line--;
	}
	else if ((tag = is_tag( line[1] )) != TAG_none)
	{
	  if (!check_tag( tag, &line, in ))
	    return E_SYNTAX;
	  if (*line == '{' &&
	      (tag == TAG_bold || tag == TAG_color || tag == TAG_font ||
	       tag == TAG_italic || TAG_underline))
	  {
	    if (tag_top == TAG_STK)
	      return E_SYNTAX;
	    tag_stk[tag_top++] = tag + 1;
	    ++line;
	  }
	  start = line--;
	}
	else
	{
	  start = ++line;
	}
      }
      else if (*line == '}' && tag_top != 0)
      {
	AddText( start, line - start );
	--line;
	if (!check_tag( tag_stk[--tag_top], &line, in ))
	  return E_SYNTAX;
	start = line--;
      }
      else if (*line == '<')
      {
	AddText( start, line - start );
	AddText( L"&lt;", 4 );
	start = line + 1;
      }
      else if (*line == '>')
      {
	if (in_tag)
	{
	  in_tag = FALSE;
	  AddString( start, line - start + 1 );
	}
	else
	{
	  AddText( start, line - start );
	  AddText( L"&gt;", 4 );
	}
	start = line + 1;
      }
      else if (*line == '&')
      {
	AddText( start, line - start );
	AddText( L"&amp;", 5 );
	start = line + 1;
      }
      else if (*line == '\t')
      {
	AddText( start, line - start );
	AddText( L"  ", 2 );
	start = line + 1;
      }
    }
    AddText( start, line - start );
    if (in_text && text[tlen-1] == ' ')
      blanks = 0;

    for (;; ++blanks)
    {
      pos = ftell( fin );
      line = GetLine( fin );
      if (line == NULL)
      {
	goto finished;
      }
      if (!SPACE( *line ) && *line != '\0')
      {
	--line_num;
	fseek( fin, pos, SEEK_SET );
	goto finished;
      }
      while (SPACE( *line ))
	++line;
      if (*line == ';')
      {
	--blanks;
	continue;
      }
      TrimComment( line );
      if (*line == '\0' || (*line == '\\' && line[1] == '\0'))
	continue;

      if (blanks > 0)
      {
	DoneText();
	AddTRA();
	do AddString( L"<PARA/>", 7 ); while (--blanks != 0);
      }
      break;
    }
  }
finished:

  DoneText();
  if (blanks != 0)
    AddString( L"<PARA/>", 7 );

  return E_OK;
}
