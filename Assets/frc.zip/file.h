/*
  file.h - File reading routines.

  Jason Hood, 6 June, 2010.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

extern BOOL unicode;
extern int  line_num;

FILE*  Open( LPCSTR );
int    GetChar( FILE* );
LPWSTR GetLine( FILE* );
